

<?php $__env->startSection('content'); ?>

<?php if(Auth::guest()): ?>
    <script type="text/javascript">
        window.location = "<?php echo e(url('/login')); ?>";
    </script>
<?php elseif($user = Auth::user()): ?>

    <?php if($user->correoUser == $memeActualizar->user->correoUser || $user->tipoUser == 'Admin'): ?>

    <div class="row mt-3">
        <div class="col-md-12">

            
            <center>
            <div class="col-md-8">
                <div class="card mx-auto">
                    <div class="card-header bg-dark">
                        <h3 class="text-center text-white">Editar Meme</h3>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('updateMeme', $memeActualizar->idMeme)); ?>" method="POST" id="editarMeme">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="tituloMeme">Titulo:</label>
                                <input type="text" name="tituloMeme" id="tituloMeme" class="form-control" value="<?php echo e($memeActualizar->tituloMeme); ?>">
                            </div>
                            
                            <div class="form-group">
                                <embed id="memeFile" src="<?php echo e(url('storage/memes/'.$memeActualizar->rutaMeme)); ?>" height="300">
                            </div>

                            <div class="form-group">
                                <label id="tagsLabel">Tag/s:<br/><small>(Haga click en un tag para removerlo)</small></label>
                                <div id="tagSpans">
                                    <!--Ejemplo de Span e Input
                                        <span class="badge badge-primary m-1">nombreTag</span>
                                        <input type="hidden" name="tags[]" value="nombreTag"/>
                                    -->
                                    <?php $__currentLoopData = $memeActualizar->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(strlen($tag->nombreTag)>50): ?>
                                        <span class="badge badge-primary m-1"><?php echo e(substr($tag->nombreTag ,0, 50)."..."); ?></span>
                                        <?php else: ?>
                                        <span class="badge badge-primary m-1"><?php echo e($tag->nombreTag); ?></span>
                                        <?php endif; ?>
                                        <input id="<?php echo e($tag->nombreTag.'_input'); ?>" type="hidden" name="tags[]" value="<?php echo e($tag->nombreTag); ?>"/>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input type="text" name="tag_search" id="tag_search" placeholder="Ingresa un tag" class="form-control">
                                    </div>
                                    <div id="tag_list"></div>                    
                                </div>
                            </div>
                            

                            <button type="submit" class="btn btn-outline-success btn-block">Editar</button>
                        </form>
                        <hr/>
                        <form action="<?php echo e(route('eliminarMeme', $memeActualizar->idMeme)); ?>" method="POST" class="d-inline" onsubmit="return confirm('¿Esta seguro que desea eliminar el meme?');">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger mx-auto">Eliminar Meme</button>
                        </form>
                    

                        <?php if(session('agregar')): ?>
                            <div class="alert alert-success mt-3">
                                <?php echo e(session('agregar')); ?>

                            </div>
                        <?php endif; ?>
                    
                        <script type="text/javascript">
                            $(document).ready(function () {

                                $('#tag_search').on('keyup',function() {
                                    var query = $(this).val(); 
                                    $.ajax({ 
                                        type:'GET',
                                        url:"<?php echo e(route('searchTag')); ?>",
                                        data:{'nombreTag':query, 'tipo':'enMeme'},
                                        success:function(data){
                                            $('#tag_list').html(data);
                                        },
                                        error:function(){
                                            alert("Sucedio un error en la operación\nInicie Sesion si no lo ha hecho");
                                        }
                                    });
                                });

                                $(document).on('click', 'li.memeli', function(){
                                    var nombreTag = $(this).data('value');
                                    var tagSpans = $('#tagSpans');
                                    $('#tag_list').html("");
                                    //Agrego una span representativa del tag, con la opcion de eliminarlo del array
                                    if(nombreTag.length>50) nombreTag = nombreTag.substring(0, 50)+"...";
                                    
                                    $('<span />', {
                                        class: 'badge badge-primary m-1',
                                        text: nombreTag
                                    }).appendTo(tagSpans);

                                    //Agrego el tag al array
                                    $('<input />', { 
                                        type: 'hidden',
                                        name: 'tags[]',
                                        id: nombreTag+"_input",
                                        value: nombreTag
                                    }).appendTo(tagSpans);
                                });

                                $(document).on('click', 'span', function(){
                                    //Elimino el tag del array y tambien su badge
                                    var nombreTag = $(this).text();
                                    document.getElementById(nombreTag+"_input").remove();
                                    $(this).remove();
                                });

                            });
                        </script>
                    </div>
                </div>
            </div>
            
            </center>

        </div>
    
    </div>
    <?php else: ?>
    <script type="text/javascript">
        window.location = "<?php echo e(route('index')); ?>";
    </script>
    <?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Esteban\Documents\GitHub\memet\resources\views/editarMeme.blade.php ENDPATH**/ ?>