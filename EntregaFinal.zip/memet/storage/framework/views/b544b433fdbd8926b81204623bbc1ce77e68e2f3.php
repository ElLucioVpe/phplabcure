

<?php $__env->startSection('content'); ?>
    <div class="perfil">
            <div class="modal-content w-75 mx-auto mt-3">
                <div class="modal-header mx-auto">
                    <h4 class="modal-title">Perfil de <?php echo e($userMostrar->nickUser); ?>

                        <?php if($user = Auth::user()): ?>
                            <?php if($user->correoUser == $userMostrar->correoUser || $user->tipoUser == 'Admin'): ?>
                            <a href="<?php echo e(route('editarUser', ['correoUser' => $userMostrar->correoUser])); ?>"><i class="fa fa-edit"></i></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </h4>
                </div>
                <div class="modal-body">
                    <div class="form-inline">
                        <div class="mx-4">
                            <img src="<?php echo e(url('storage/avatar/'.$userMostrar->avatarUser)); ?>" name="avatar" width="140" height="140" border="0">
                        </div>
                        <div class="datos-user">
                            <h3 class="media-heading"><?php echo e($userMostrar->nickUser); ?>

                                <?php if($recompensas->titulo != ""): ?>
                                    <small>[<?php echo e($recompensas->titulo); ?>]</small>
                                <?php endif; ?>
                                <small><span class="badge badge-info">Nivel <?php echo e($nivelUser); ?></span></small>
                            </h3>
                            
                            <?php if(!empty($recompensas->medallas) || $userMostrar->tipoUser == 'Admin'): ?>
                                <h5>
                                    <?php $__currentLoopData = $recompensas->medallas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medalla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <!-- Las medallas se guardan como html para poder ser mas personalizadas -->
                                        <?php echo $medalla; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($userMostrar->tipoUser == 'Admin'): ?>
                                        <span class="badge badge-pill badge-primary"><i class="fa fa-star"></i>Admin<i class="fa fa-star"></i></span>
                                    <?php endif; ?>
                                </h5>
                                <hr/>
                            <?php endif; ?>

                            <h5>
                                <?php if($userMostrar->memes->count() == 1): ?>
                                    <span class="badge badge-success"><?php echo e($userMostrar->memes->count()); ?> Publicacion</span>
                                <?php else: ?>
                                    <span class="badge badge-success"><?php echo e($userMostrar->memes->count()); ?> Publicaciones</span>
                                <?php endif; ?>
                            <h5>
                        </div>
                        
                    </div>
                    
                </div>
                <div class="modal-footer">
                    <table class="table">
                        <tr>
                            <th>Publicaciones</th>
                        </tr>
                        <?php $__currentLoopData = $userMostrar->memes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a class="text-dark font-weight-bold" href="<?php echo e(route('mostrarMeme',['idMeme'=>$meme->idMeme])); ?>">
                                        <?php echo e($meme->tituloMeme); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Esteban\Documents\GitHub\memet\resources\views/perfilUser.blade.php ENDPATH**/ ?>