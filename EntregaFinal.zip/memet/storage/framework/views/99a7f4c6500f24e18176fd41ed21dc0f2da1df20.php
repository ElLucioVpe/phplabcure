

<?php $__env->startSection('content'); ?>
    <!-- El yield aca cambia el content -->
    <div class="pt-5 container">
        <div class="row">
            
            <div class="col">
                <nav style="width:75%; margin:auto">
                    <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                        <a class="nav-item nav-link active bg-dark text-white" id="nav-new-tab" data-toggle="tab" href="#nav-new" role="tab" aria-controls="nav-new" aria-selected="true">NEW</a>
                        <a class="nav-item nav-link bg-dark text-white" id="nav-hot-tab" data-toggle="tab" href="#nav-hot" role="tab" aria-controls="nav-hot" aria-selected="false">HOT</a>
                        <a class="nav-item nav-link bg-dark text-white" id="nav-rec-tab" data-toggle="tab" href="#nav-rec" role="tab" aria-controls="nav-rec" aria-selected="false">RECOMENDADOS</a>
                    </div>
                </nav>
                    <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-new" role="tabpanel" aria-labelledby="nav-new-tab">
                            <?php $__currentLoopData = $memesNEW; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card mx-auto meme-card">
                                <div class="card-body">
                                    <small class="card-text autor">
                                        <a href="<?php echo e(url('perfilUser').'/'.($meme->user->correoUser ?? 'eliminado')); ?>" style="color:black;">
                                            <?php echo e($meme->user->nickUser ?? 'usuario eliminado'); ?>

                                        </a>
                                    </small>
                                    <p class="card-text titulo"><a href="<?php echo e(url('mostrarMeme/'.$meme->idMeme)); ?>" style="color:black"><?php echo e($meme->tituloMeme); ?></a></p>
                                    <img class="card-img-bottom" src="<?php echo e(url('storage/memes/'.$meme->rutaMeme)); ?>">
                                    <div class="d-flex justify-content-between align-items-center mt-1">
                                        <div class="btn-group">
                                            <button id="like" type="button" class="btn btn btn-outline-dark" onclick="puntuarMeme('1')">
                                                <i class="fa fa-thumbs-up"></i>
                                            </button>
                                            <button id="dislike" type="button" class="btn btn btn-outline-dark" onclick="puntuarMeme('0')">
                                                <i class="fa fa-thumbs-down"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="tab-pane fade justify-content-center" id="nav-hot" role="tabpanel" aria-labelledby="nav-hot-tab">
                            <?php $__currentLoopData = $memesHOT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card mx-auto meme-card">
                                <div class="card-body">
                                    <small class="card-text autor">
                                        <a href="<?php echo e(url('perfilUser').'/'.($meme->user->correoUser ?? 'eliminado')); ?>" style="color:black;">
                                            <?php echo e($meme->user->nickUser ?? 'usuario eliminado'); ?>

                                        </a>
                                    </small>
                                    <p class="card-text titulo"><a href="<?php echo e(url('mostrarMeme/'.$meme->idMeme)); ?>" style="color:black"><?php echo e($meme->tituloMeme); ?></a></p>
                                    <img class="card-img-bottom" src="<?php echo e(url('storage/memes/'.$meme->rutaMeme)); ?>">
                                    <div class="d-flex justify-content-between align-items-center mt-1">
                                        <div class="btn-group">
                                            <button id="like" type="button" class="btn btn btn-outline-dark" onclick="puntuarMeme('1')">
                                                <i class="fa fa-thumbs-up"></i>
                                            </button>
                                            <button id="dislike" type="button" class="btn btn btn-outline-dark" onclick="puntuarMeme('0')">
                                                <i class="fa fa-thumbs-down"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="tab-pane fade justify-content-center" id="nav-rec" role="tabpanel" aria-labelledby="nav-rec-tab">
                            <?php $__currentLoopData = $memesREC; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card mx-auto meme-card">
                                <div class="card-body">
                                    <small class="card-text autor">
                                        <a href="<?php echo e(url('perfilUser').'/'.($meme->user->correoUser ?? 'eliminado')); ?>" style="color:black;">
                                            <?php echo e($meme->user->nickUser ?? 'usuario eliminado'); ?>

                                        </a>
                                    </small>
                                    <p class="card-text titulo"><a href="<?php echo e(url('mostrarMeme/'.$meme->idMeme)); ?>" style="color:black"><?php echo e($meme->tituloMeme); ?></a></p>
                                    <img class="card-img-bottom" src="<?php echo e(url('storage/memes/'.$meme->rutaMeme)); ?>">
                                    <div class="d-flex justify-content-between align-items-center mt-1">
                                        <div class="btn-group">
                                            <button id="like" type="button" class="btn btn btn-outline-dark" onclick="puntuarMeme('1')">
                                                <i class="fa fa-thumbs-up"></i>
                                            </button>
                                            <button id="dislike" type="button" class="btn btn btn-outline-dark" onclick="puntuarMeme('0')">
                                                <i class="fa fa-thumbs-down"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Esteban\Documents\GitHub\memet\resources\views/index.blade.php ENDPATH**/ ?>