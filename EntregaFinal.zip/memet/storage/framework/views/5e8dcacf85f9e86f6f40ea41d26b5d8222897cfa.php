

<?php $__env->startSection('content'); ?>

    <div class="pt-5 container">
        <div class="row">
            <div class="col">
                <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="nav-memes" role="tabpanel" aria-labelledby="nav-new-tab">
                        <?php $__currentLoopData = $memes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mx-auto" style="width: 32rem;">
                            <div class="card-body">
                                <small class="card-text autor">
                                    <a href="<?php echo e(url('perfilUser').'/'.($meme->user->correoUser ?? 'eliminado')); ?>" style="color:black;">
                                        <?php echo e($meme->user->nickUser ?? 'usuario eliminado'); ?>

                                    </a>
                                </small>
                                <p class="card-text titulo"><a href="<?php echo e(url('mostrarMeme/'.$meme->idMeme)); ?>" style="color:black"><?php echo e($meme->tituloMeme); ?></a></p>
                                <img class="card-img-bottom" src="<?php echo e(url('storage/memes/'.$meme->rutaMeme)); ?>">
                                <div class="d-flex justify-content-between align-items-center mt-1">
                                    <div class="btn-group">
                                        <button id="like" type="button" class="btn btn btn-outline-dark" onclick="puntuarMeme('1')">
                                            <i class="fa fa-thumbs-up"></i>
                                        </button>
                                        <button id="dislike" type="button" class="btn btn btn-outline-dark" onclick="puntuarMeme('0')">
                                            <i class="fa fa-thumbs-down"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <?php if($user = Auth::user()): ?>
        <script type="text/javascript"> var user = '<?php echo e($user->correoUser); ?>'; </script>
    <?php else: ?> 
        <script type="text/javascript"> var user = "none"; </script>
    <?php endif; ?>

    <script type="text/javascript">
        function puntuarMeme(value) {
            var meme = <?php echo e($meme->idMeme); ?>;
            console.log(user);
            if(user != "none") {
                $.ajax({ 
                    type:'POST',
                    url:"<?php echo e(url('/puntuarMeme')); ?>"+'/'+user+'/'+meme+'/'+value,
                    success:function(data){
                        console.log(data);
                        var span = "like-span";
                        var anti_span = "dislike-span";
                        if(data[1] == 0) {
                            span = "dislike-span";
                            anti_span = "like-span";
                        }

                        if(data[0] == "store") 
                            document.getElementById(span).textContent = parseInt(document.getElementById(span).innerText)+1;
                        else if(data[0] == "destroy")
                            document.getElementById(span).textContent = parseInt(document.getElementById(span).innerText)-1;
                        else if(data[0] == "update") {
                            document.getElementById(span).textContent = parseInt(document.getElementById(span).innerText)+1;
                            document.getElementById(anti_span).textContent = parseInt(document.getElementById(anti_span).innerText)-1;
                        }
                        
                    },
                    error:function() {
                        console.log("Sucedio un error en la puntuacion");
                    }
                });
            } else alert("Inicie Sesion");
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Esteban\Documents\GitHub\memet\resources\views/buscar.blade.php ENDPATH**/ ?>