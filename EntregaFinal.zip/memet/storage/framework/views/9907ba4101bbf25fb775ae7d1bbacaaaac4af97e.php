

<?php $__env->startSection('content'); ?>

<?php if($user = Auth::user()): ?>

 <?php if($user->correoUser == $correoUser || $user->tipoUser == 'Admin'): ?>
 <div class="pt-5 row">
    <div class="col-md-8 mx-auto">
        <div class="card text-center mx-auto">
            <div class="card-header bg-dark">
                <h2 class="text-white">Suscripciones</h2>
            </div>
            <div class="card-body">

                <table class="table">
                    <tr>
                        <th>Tag</th>
                        <th>Tipo</th>
                        <th>Acciones</th>
                    </tr>
                    <?php $__currentLoopData = $suscripciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($sus->Tag_nombreTag); ?></td>
                            <?php if($sus->ignora): ?>
                                <td>Ignorado</td>
                            <?php else: ?>
                                <td>Seguido</td>
                            <?php endif; ?>
                            <td>
                                <form action="<?php echo e(route('eliminarSuscripcion',['correoUser'=>$sus->User_correoUser, 'tag'=>$sus->Tag_nombreTag])); ?>" method="POST" class="d-inline">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
                <?php if(session('eliminarSuscripcion')): ?>
                    <div class="alert alert-success mt-3">
                        <?php echo e(session('eliminarSuscripcion')); ?>

                    </div>
                <?php endif; ?>
            
            </div>
        </div>
    </div>
 </div>
 <?php else: ?>
    <script type="text/javascript">
        window.location = "<?php echo e(route('index')); ?>";
    </script>
 <?php endif; ?>
<?php else: ?>
    <script type="text/javascript">
        window.location = "<?php echo e(route('index')); ?>";
    </script>
<?php endif; ?>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Esteban\Documents\GitHub\memet\resources\views/suscripciones.blade.php ENDPATH**/ ?>