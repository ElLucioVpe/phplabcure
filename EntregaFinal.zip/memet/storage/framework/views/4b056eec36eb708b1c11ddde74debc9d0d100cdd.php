

<?php $__env->startSection('content'); ?>

    <div class="info-meme">
        <div class="modal-content w-75 mx-auto mt-3">
            <div id="user-link" class="modal-header">
                <div class="form-inline">
                    <small>Subido por:&nbsp</small>
                    <a href="<?php echo e(url('perfilUser').'/'.($memeMostrar->user->correoUser ?? 'eliminado')); ?>" style="color:black;">
                        <?php echo e($memeMostrar->user->nickUser ?? 'usuario eliminado'); ?>

                    </a>
                </div>
                <?php if($user = Auth::user()): ?>
                    <?php if($user->correoUser == $memeMostrar->user->correoUser || $user->tipoUser == 'Admin'): ?>
                        <a href="<?php echo e(route('editarMeme', $memeMostrar->idMeme)); ?>"><i class="fa fa-edit"></i></a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="modal-header">
                <h5 class="modal-title"><?php echo e($memeMostrar->tituloMeme); ?></h5>
                <p class="media-heading">
                    <small><?php echo e($memeMostrar->fechaMeme); ?></small>
                </p>
            </div>
            <div class="modal-body mx-auto">
                <div class="div-meme">
                    <img src="<?php echo e(url('storage/memes/'.$memeMostrar->rutaMeme)); ?>" name="meme" width="100%" height="auto" border="0">
                </div>   
            </div>
            <div class="modal-footer-float-left">
                <div class="tags-meme form-inline">
                    <?php $__currentLoopData = $memeMostrar->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <h5>
                            <span class="badge badge-secondary mx-1">
                                <a onclick="mostrarVentanaTag('<?php echo e($tag->nombreTag); ?>')" href="#aboutModal" data-toggle="modal" 
                                    data-target="#tagActions" style="color: white;">
                                <?php if(strlen($tag->nombreTag)<=50): ?>
                                    <?php echo e($tag->nombreTag); ?>

                                <?php else: ?>
                                    <?php echo e(substr($tag->nombreTag, 0, 50)."..."); ?>

                                <?php endif; ?>
                                </a>
                            </span>
                        </h5>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- Ventana Suscribirse/Ignorar Tag -->
                <div class="modal fade" id="tagActions" tabindex="-1" role="dialog" aria-labelledby="tagActionsLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header mx-auto">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                <h4 class="modal-title" id="tagActionsLabel">Tag</h4>
                                </div>
                            <div class="modal-body mx-auto">
                                <button type="button" class="btn btn-outline-success" data-dismiss="modal" onclick="accionTag(false)">
                                    Suscribirse
                                </button>
                                <button type="button" class="btn btn-outline-danger" data-dismiss="modal" onclick="accionTag(true)">
                                    Ignorar
                                </button>
                            </div>
                            <div class="modal-footer mx-auto">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- -->
                <hr/>
                <div class="form-inline">
                    <h5 class="mx-auto">
                        <button id="like" type="button" class="btn btn-outline-dark" onclick="puntuarMeme('1')">
                            <i class="fa fa-thumbs-up"></i>
                            <span id="like-span" class="badge badge-success"><?php echo e($puntuaciones[0]); ?></span>
                        </button>
                        <button id="dislike" type="button" class="btn btn-outline-dark" onclick="puntuarMeme('0')">
                            <i class="fa fa-thumbs-down"></i>
                            <span id="dislike-span" class="badge badge-danger"><?php echo e($puntuaciones[1]); ?></span>
                        </button>
                    </h5>
                </div>
            </div>
            <div id="comments">
                <?php echo $__env->make('comments::components.comments', [
                    'model' => $memeMostrar,
                    'perPage' => 50
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>

    <?php if($user = Auth::user()): ?>
        <script type="text/javascript"> var user = '<?php echo e($user->correoUser); ?>'; </script>
    <?php else: ?> 
        <script type="text/javascript"> var user = "none"; </script>
    <?php endif; ?>

    <script type="text/javascript">

        function puntuarMeme(value) {
            var meme = <?php echo e($memeMostrar->idMeme); ?>;
            console.log(user);
            if(user != "none") {
                $.ajax({ 
                    type:'POST',
                    url:"<?php echo e(url('/puntuarMeme')); ?>"+'/'+user+'/'+meme+'/'+value,
                    success:function(data){
                        console.log(data);
                        var span = "like-span";
                        var anti_span = "dislike-span";
                        if(data[1] == 0) {
                            span = "dislike-span";
                            anti_span = "like-span";
                        }

                        if(data[0] == "store") 
                            document.getElementById(span).textContent = parseInt(document.getElementById(span).innerText)+1;
                        else if(data[0] == "destroy")
                            document.getElementById(span).textContent = parseInt(document.getElementById(span).innerText)-1;
                        else if(data[0] == "update") {
                            document.getElementById(span).textContent = parseInt(document.getElementById(span).innerText)+1;
                            document.getElementById(anti_span).textContent = parseInt(document.getElementById(anti_span).innerText)-1;
                        }
                        
                    },
                    error:function() {
                        console.log("Sucedio un error en la puntuacion");
                    }
                });
            } else alert("Inicie Sesion");
        }

        function mostrarVentanaTag(tag) {
            $('#tagActionsLabel').html(tag);
            //console.log('update label to:'+$('#tagActionsLabel').html);
        }

        function accionTag(ignora) {
            var tag = $('#tagActionsLabel').html();

            if(user != "none") {
                $.ajax({ 
                    type:'POST',
                    url:"<?php echo e(url('/suscribirseTag')); ?>"+'/'+ignora+'/'+tag+'/'+user,
                    success:function(data){
                        if(data == "store" || data == "update") {
                            if(!ignora) alert("Usted se ha suscripto al tag con exito");
                            else alert("Usted ha ignorado el tag con exito");
                        } else if(data == "destroy") {
                            if(!ignora) alert("Usted ya estaba suscripto al tag, por lo tanto ha dejado de estarlo");
                            else alert("Usted ya habia ignorado el tag, por lo tanto ha dejado de hacerlo");
                        }
                    },
                    error:function(){
                        alert("Sucedio un error en la operación\nInicie Sesion si no lo ha hecho");
                    }
                });
            } else alert("Inicie Sesion");
        }

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Esteban\Documents\GitHub\memet\resources\views/mostrarMeme.blade.php ENDPATH**/ ?>