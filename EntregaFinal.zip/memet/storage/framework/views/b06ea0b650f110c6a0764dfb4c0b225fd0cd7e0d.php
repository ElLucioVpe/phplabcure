

<?php $__env->startSection('content'); ?>

<?php if($user = Auth::user()): ?>

 <?php if($user->correoUser == $userActualizar->correoUser || $user->tipoUser == 'Admin'): ?>
<div class="pt-5 row">
    <div class="col-md-12">
        <center>
        <div class="col-md-8">
            <div class="card mx-auto">
                <div class="card-header bg-dark">
                    <h3 class="text-center text-white">Edita Tu Perfil <?php echo e($userActualizar->nickUser); ?></h3>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('updateUser', $userActualizar->correoUser)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input type="text" name="nickUser" id="nickUser" class="form-control" value=" <?php echo e($userActualizar->nickUser); ?>">
                        </div>
                        <div class="form-group">
                            <input type="password" name="passwordUser" id="passwordUser" class="form-control" placeholder="***************">
                        </div>
                        <div>
                            <center>
                                <img src="<?php echo e(url('storage/avatar/'.$userActualizar->avatarUser)); ?>" height="150" width=auto>
                            </center>
                        </div>
                        <div class="form-group">
                            <input type="file" name="avatar" id="avatar" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-outline-success btn-block">Modificar</button>

                    </form>
                    <hr/>
                    <center>
                    <form action="<?php echo e(route('eliminarUser', $userActualizar->correoUser)); ?>" method="POST" class="d-inline" onsubmit="return confirm('¿Esta seguro que desea eliminar su cuenta?');">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger mx-auto">Eliminar Cuenta</button>
                    </form>
                    </center>
                </div>
            </div>
        </div>
    </div>
    <?php if(session('update')): ?>
    <div class="alert alert-success mt-3">
        <?php echo e(session('update')); ?>

    </div>
    <?php endif; ?>
</div>
 <?php else: ?>
    <script type="text/javascript">
        window.location = "<?php echo e(route('index')); ?>";
    </script>
 <?php endif; ?>
<?php else: ?>
    <script type="text/javascript">
        window.location = "<?php echo e(route('index')); ?>";
    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Esteban\Documents\GitHub\memet\resources\views/editarUser.blade.php ENDPATH**/ ?>